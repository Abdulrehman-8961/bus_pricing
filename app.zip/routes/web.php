<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileSettings;
use App\Http\Controllers\BusController;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return redirect('/home');
// });
Route::get('/', [App\Http\Controllers\FrontEndController::class, 'index']);
Route::post('/Estimated-Price', [App\Http\Controllers\FrontEndController::class, 'calculation']);


Auth::routes();
Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

// Profile Settings
Route::get('/profile-settings', [ProfileSettings::class, 'settings']);
Route::post('/profile-settings/update', [ProfileSettings::class, 'update_profile']);
Route::post('/profile-settings/update-password', [ProfileSettings::class, 'update_password']);


// Bus type
Route::get('/Bus-Type', [BusController::class, 'view'])->name('bus.type');
Route::get('/Bus-Type/Add', [BusController::class, 'add'])->name('bus.type.add');
Route::post('/Bus-Type/Save', [BusController::class, 'save'])->name('bus.type.save');
Route::get('/Bus-Type/Edit/{id}', [BusController::class, 'edit'])->name('bus.type.edit');
Route::post('/Bus-Type/Update/{id}', [BusController::class, 'update'])->name('bus.type.update');
Route::get('/Bus-Type/delete/{id}', [BusController::class, 'delete'])->name('bus.type.delete');
Route::get('/bus_details/{id}', [BusController::class, 'bus_details']);

// Employee
Route::get('/Employees', [UserController::class, 'view']);
Route::get('/Employee/add', [UserController::class, 'add']);
Route::post('/Employee/save', [UserController::class, 'save']);
Route::get('/Employee/edit/{id}', [UserController::class, 'edit']);
Route::post('/Employee/update/{id}', [UserController::class, 'update']);
Route::post('/Employee/update-password/{id}', [UserController::class, 'update_password']);
Route::get('/Employee/delete/{id}', [UserController::class, 'delete']);

