@extends('layouts.dashboard')

@section('content')
    <div class="container-fluid">
        <div class="row mt-4">
            <div class="col-lg-12 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h3 class="text-center"> Welcome {{ Auth::user()->name }}!</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
