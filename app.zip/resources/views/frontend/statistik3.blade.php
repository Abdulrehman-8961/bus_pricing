<!DOCTYPE html>
<html>

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Buspreiskalkulation</title>
    <style>
        body {
            background-image: url('{{ asset('public') }}/assets/img/bus-mieten-1.jpg');
            /* Replace 'your-image-path.jpg' with the actual path to your image */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            min-height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            background: rgba(0, 0, 0, 0.3);
            /* Adjust the alpha value for transparency */
            z-index: -1;
            /* Place the overlay behind the content */
        }

        .container {
            width: 100%;
            position: relative;
            z-index: 1;
            /* Ensure the container is above the overlay */
        }

        .card {
            background-color: rgba(255, 255, 255);
            border-top: 6px solid black;
            border-radius: 0rem !important;
            /* Set the background color of the card with some opacity */
        }

        .btn-submit {
            margin: 2px;
            background-image: linear-gradient(161deg, #990B0C 82%, #990B0C 100%);
            color: #fff;
            padding-right: 20px;
            padding-left: 20px;
        }

        .btn-submit:hover {
            background-image: linear-gradient(180deg, #2B2B2B 0%, #2B2B2B 100%);
            color: #fff;
        }

        .btn:focus {
            box-shadow: none !important;
        }

        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        input[type=number] {
            -moz-appearance: textfield;
        }

        .form-label {
            margin-bottom: 1rem;
            /* Add margin between label and input field */
        }

        .form-control {
            border-radius: 0.50rem !important;
        }


        .form-control:focus {
            border-color: #CED4DA !important;
            box-shadow: none !important;
            outline: none;
        }

        .custom-background {
            background-color: white;
            padding: 25px;
            /* Abstand von oben */
            margin-top: 25px;
        }
    </style>
</head>

<body>
    <div class="container mx-auto">
        <!-- <div class="row mb-3 mt-2">
            <p class="text-white fs-2">Deutschland und Europaweit</p>
        </div>
        <div class="row mb-2">
            <h1 class="text-white fw-bolder">Eigenen Bus mit Fahrer mieten</h1>
        </div> -->
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-8 mb-3">
                        <p>Die Gesamtdauer beträgt <span class="fw-bold"><?php echo number_format($dauerInDezimaltagen, 2); ?></span> Tage in
                            Dezimalzahlen und <?php echo number_format($dauerStunden, 2); ?> Stunden</p>
                    </div>
                </div>
                <?php if($kostenvoranschlag){ ?>
                <div class="row">
                    <div class="col-md-8 mb-3">
                        <p>Der Kostenvoranschlag beträgt: <span class="fw-bold">€<?php echo number_format(ceil($kostenvoranschlag), 2, ',', '.'); ?></span>.</p>
                        <p> Nettopreis: <span class="fw-bold">€<?php echo number_format(ceil($nettopreis), 2, ',', '.'); ?></span>.</p>
                        <p> Geschätzter EK: <span class="fw-bold">€<?php echo number_format(ceil($gek), 2, ',', '.'); ?> inkl.</span></p>

                        <?php if($note != ""){ ?>
                        <p class="fw-bold"><?php echo $zusaetzlicheInfo; ?>
                        </p>
                        <?php } ?>
                    </div>
                </div>
                <?php } else { ?>
                <div class="row">
                    <div class="col-md-8 mb-3">
                        <p class="fw-bold">Für die angegebene Personenanzahl ist kein passender Bustyp verfügbar.</p>
                    </div>
                </div>
                <?php }  ?>
                <div class="row">
                    <div class="col-auto mb-3">
                        <a href="{{ url('/') }}" class="btn btn-submit">ZURÜCK</a>
                    </div>


                </div>
            </div>
        </div>



        <div class="custom-background">
            <!-- Ungeordnete Liste (ul) für die Busdaten -->
            <div class="row">
                <div class="col-md-4 mb-3">
                    <h3>Bundeslandzuschläge</h3>
                    <ul>
                        <li>Schleswig-Holstein + 15%</li>
                        <li>Mecklenburg-Vorpommern + 20%</li>
                        <li>Bayern + 20%</li>
                        <li>Baden-Württemberg + 20%</li>
                    </ul>
                </div>

                <div class="col-md-4 mb-3">
                    <h3>Saisonzuschläge</h3>
                    <ul>
                        <li>Juni & September immer von Freitags bis Montags + 20%</li>
                        <li style="margin-top:15px;  background: #e3e3e3; padding: 25px;"><b>Hinweis:</b> Bitte an
                            Wochenenden im Juni und September aufgrund von Kapazitätsengpässen stets mit der Dispo
                            Rücksprache halten.</li>
                    </ul>
                </div>

                <div class="col-md-4 mb-3">
                    <h3>EM 2024</h3>
                    <ul>
                        <li>Juni & Juli vorläufig immer +5% <br>(außer Fr-Mo im Juni +20%)</li>

                    </ul>
                </div>

            </div>
        </div>


        <!-- ENDE -->
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
</body>

</html>
