<!DOCTYPE html>
<html>

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link id="themeColors" rel="stylesheet" href="{{ asset('public') }}/dist/css/style.min.css" />
    <title>Buspreiskalkulation</title>
    <style>
        body {
            background-image: url('{{ asset('public') }}/assets/img/bus-mieten-1.jpg');
            /* Replace 'your-image-path.jpg' with the actual path to your image */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            min-height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            background: rgba(0, 0, 0, 0.3);
            /* Adjust the alpha value for transparency */
            z-index: -1;
            /* Place the overlay behind the content */
        }

        .container {
            width: 100%;
            position: relative;
            z-index: 1;
            /* Ensure the container is above the overlay */
        }

        .card {
            background-color: rgba(255, 255, 255);
            border-top: 6px solid black;
            border-radius: 0rem !important;
            /* Set the background color of the card with some opacity */
        }

        .btn-submit {
            margin: 2px;
            background-image: linear-gradient(161deg, #990B0C 82%, #990B0C 100%);
            color: #fff;
            padding-right: 20px;
            padding-left: 20px;
        }

        .btn-submit:hover {
            background-image: linear-gradient(180deg, #2B2B2B 0%, #2B2B2B 100%);
            color: #fff;
        }

        .btn:focus {
            box-shadow: none !important;
        }

        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        input[type=number] {
            -moz-appearance: textfield;
        }

        .form-label {
            margin-bottom: 1rem;
            /* Add margin between label and input field */
        }

        .form-control {
            border-radius: 12px !important;
        }


        .form-control:focus {
            border-color: #CED4DA !important;
            box-shadow: none !important;
            outline: none;
        }

        .custom-background {
            background-color: white;
            padding: 25px;
            /* Abstand von oben */
            margin-top: 25px;
        }
        .page-wrapper{
            width: 100% !important;
        }
        .body-wrapper{
            margin-left: 0px !important;
        }
        header{
            width: 100% !important;
            margin-top: -10px;
            background: transparent !important;
        }
    </style>
</head>

<body>
    <div class="page-wrapper" id="main-wrapper" data-theme="blue_theme" data-layout="vertical" data-sidebartype="full"
        data-sidebar-position="fixed" data-header-position="fixed">
        <div class="body-wrapper">
            @auth
                <header class="app-header">
                    <nav class="navbar navbar-expand-lg navbar-light">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                {{-- <a class="nav-link sidebartoggler nav-icon-hover ms-n3" id="headerCollapse"
                                    href="javascript:void(0)">
                                    <i class="ti ti-menu-2"></i>
                                </a> --}}
                            </li>
                        </ul>
                        <div class="d-block d-lg-none">
                            <img src="{{ asset('public') }}/dist/images/backgrounds/logo.png" class="dark-logo"
                                width="150" alt="" />
                            <img src="{{ asset('public') }}/dist/dist/images/backgrounds/logo.png" class="light-logo"
                                width="150" alt="" />
                            {{-- <h3 class="dark-logo text-dark fw-bolder">Kleen-air Filters</h3>
                                <h3 class="light-logo text-white fw-bolder">Kleen-air Filters</h3> --}}
                        </div>
                        <button class="navbar-toggler p-0 border-0" type="button" data-bs-toggle="collapse"
                            data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
                            aria-label="Toggle navigation">
                            <span class="p-2">
                                {{-- <i class="ti ti-dots fs-7"></i> --}}
                            </span>
                        </button>
                        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                            <div class="d-flex align-items-center justify-content-between">
                                <a href="javascript:void(0)"
                                    class="nav-link d-flex d-lg- none d-none align-items-center justify-content-center"
                                    type="button" data-bs-toggle="offcanvas" data-bs-target="#mobilenavbar"
                                    aria-controls="offcanvasWithBothOptions">
                                    <i class="ti ti-align-justified fs-7"></i>
                                </a>
                                <ul class="navbar-nav flex-row ms-auto align-items-center justify-content-center">
                                    <li class="nav-item dropdown">
                                        <a class="nav-link pe-0" href="javascript:void(0)" id="drop1"
                                            data-bs-toggle="dropdown" aria-expanded="false">
                                            <div class="d-flex align-items-center">
                                                <div class="user-profile-img">
                                                    <img src="{{ asset('public') }}/dist/images/profile/user-1.jpg"
                                                        class="rounded-circle" width="35" height="35"
                                                        alt="" />
                                                </div>
                                            </div>
                                        </a>
                                        <div class="dropdown-menu content-dd dropdown-menu-end dropdown-menu-animate-up"
                                            aria-labelledby="drop1">
                                            <div class="profile-dropdown position-relative" data-simplebar>
                                                <div class="py-3 px-7 pb-0">
                                                    <h5 class="mb-0 fs-5 fw-semibold">User Profile</h5>
                                                </div>
                                                <div class="d-flex align-items-center py-9 mx-7 border-bottom">
                                                    <img src="{{ asset('public') }}/dist/images/profile/user-1.jpg"
                                                        class="rounded-circle" width="80" height="80"
                                                        alt="" />
                                                    <div class="ms-3">
                                                        <h5 class="mb-1 fs-3">{{ ucwords(Auth::user()->name) }}</h5>
                                                        @if (Auth::user()->role != null)
                                                            <span
                                                                class="mb-1 d-block text-dark">{{ ucwords(Auth::user()->role) }}</span>
                                                        @endif
                                                        <p class="mb-0 d-flex text-dark align-items-center gap-2">
                                                            <i class="ti ti-mail fs-4"></i> {{ Auth::user()->email }}
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="message-body">
                                                    <a href="{{ url('/profile-settings') }}"
                                                        class="py-8 px-7 mt-8 d-flex align-items-center">
                                                        <span
                                                            class="d-flex align-items-center justify-content-center bg-light rounded-1 p-6">
                                                            <img src="{{ asset('public') }}/dist/images/svgs/icon-account.svg"
                                                                alt="" width="24" height="24">
                                                        </span>
                                                        <div class="w-75 d-inline-block v-middle ps-3">
                                                            <h6 class="mb-1 bg-hover-primary fw-semibold"> My Profile </h6>
                                                            <span class="d-block text-dark">Account Settings</span>
                                                        </div>
                                                    </a>

                                                </div>
                                                <div class="d-grid py-4 px-7 pt-8">
                                                    <a href="javascript:void(0);"
                                                        onclick="document.getElementById('logoutForm').submit();"
                                                        class="btn btn-outline-primary">Log Out</a>
                                                    <form id="logoutForm" method="POST" action="{{ url('/logout') }}">
                                                        @csrf</form>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </nav>
                </header>
            @endauth
            <div class="container mx-auto">
                <div class="row mb-3 mt-2">
                    <p class="text-white fs-2"></p>
                </div>
                <div class="row mb-2">
                    <h1 class="text-white fw-bolder" @auth
                    style="margin-top: 40px;"
                @endauth>Get Your Price</h1>
                </div>
                <div class="card">
                    <div class="card-body">
                        <form action="{{ url('Estimated-Price') }}" method="post">
                            @csrf
                            <div class="row">
                                <div class="col-lg-4 mb-3">
                                    <label for="personenanzahl" class="fw-normal form-label">Personenanzahl:</label>
                                    <input type="number" class="form-control fo " id="personenanzahl"
                                        name="personenanzahl" placeholder="Anzahl der Passagiere" required>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label for="entfernung" class="fw-normal form-label">Entfernung (in km):</label>
                                    <input type="number" class="form-control form-contr m" id="entfernung"
                                        name="entfernung" placeholder="Entfernung in Kilometern" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-4 mb-3">
                                    <label for="hinfahrtsdatum" class="fw-normal form-label">Hinfahrtsdatum und
                                        -uhrzeit:</label>
                                    <input type="datetime-local" class="form-control  " id="hinfahrtsdatum"
                                        name="hinfahrtsdatum" required>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label for="rueckfahrtdatum" class="fw-normal form-label">Rückfahrtdatum und
                                        -uhrzeit:</label>
                                    <input type="datetime-local" class="form-control  " id="rueckfahrtdatum"
                                        name="rueckfahrtdatum" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-auto mb 1 mt-2">
                                    <input type="submit" class="btn btn-submit" value="PREIS BERECHNEN">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="custom-background">
                    <!-- Ungeordnete Liste (ul) für die Busdaten -->
                    <h3>Bustypen</h3>
                    <ul>
                        @foreach ($bus_type as $bus)
                            <li>{{ $bus->name }} = {{ $bus->capacity }}</li>
                        @endforeach
                        {{-- <li>MiniVan = 8</li>
                        <li>Kleinbus = 18</li>
                        <li>Midibus = 28</li>
                        <li>Reisebus = 50</li>
                        <li>ReisebusXL = 57</li>
                        <li>Doppeldecker = 78</li> --}}
                    </ul>
                </div>

                <div class="custom-background" style="margin-bottom: 50px;">


                    <! Marge- und Rabattberechnung>
                        <html>

                        <head>
                            <style>
                                #ergebnis,
                                #hinweis {
                                    margin-top: 20px;
                                }

                                .hinweis {
                                    color: red;
                                }
                            </style>
                            <script>
                                function berechneVerkaufspreise() {
                                    var ekNetto = parseFloat(document.getElementById('ek').value);
                                    var rabatt = parseFloat(document.getElementById('rabatt').value) || 0;
                                    var mwstSatz = 19; // Mehrwertsteuersatz von 19%  VAT rate of 19%
                                    var margen = [20, 25, 30];
                                    var ergebnisText = "";
                                    var mindestmargeAngepasst = false;

                                    document.getElementById('hinweis').innerHTML = ""; // Hinweis zurücksetzen  Reset notice

                                    // Mindestmarge Anpassung ohne Rabatt für Beträge unter 1300€, Minimum margin adjustment without discount for amounts under €1300
                                    if (ekNetto < 1300) {
                                        var vkNetto = ekNetto + 200; // Mindestmarge hinzufügen, Add minimum margin
                                        var vkBrutto = vkNetto * (1 + mwstSatz /
                                            100); // Brutto berechnen ohne Rabatt, Calculate gross without discount
                                        ergebnisText = "<p>Mindestmarge: Netto: " + vkNetto.toFixed(2).replace('.', ',') + "€, Brutto: " + vkBrutto
                                            .toFixed(2).replace('.', ',') +
                                            "€</br><b>Hinweis:</b> Auf die Mindestmarge kann kein Rabatt gewährt werden.</p>";
                                        mindestmargeAngepasst = true;
                                    }

                                    if (!mindestmargeAngepasst) {
                                        for (var i = 0; i < margen.length; i++) {
                                            var angepassterRabatt = rabatt;
                                            // Rabattanpassung nur für 20% Marge
                                            if (margen[i] === 20 && rabatt > 4) {
                                                angepassterRabatt = 4; // Rabatt auf 4% beschränken
                                                document.getElementById('hinweis').innerHTML =
                                                    "<p class='hinweis'>Bei 20% Marge kann maximal 4% Rabatt gewährt werden.</p>";
                                            }

                                            var vkNettoOhneRabatt = ekNetto + (ekNetto * margen[i] / 100);
                                            var vkNettoMitRabatt = vkNettoOhneRabatt - (vkNettoOhneRabatt * angepassterRabatt /
                                                100); // Rabatt vom VK Netto abziehen
                                            var vkBruttoMitRabatt = vkNettoMitRabatt * (1 + mwstSatz / 100); // Brutto berechnen
                                            var tatsaechlicheMarge = ((vkNettoMitRabatt - ekNetto) / ekNetto) *
                                                100; // Tatsächliche Marge nach Rabatt

                                            ergebnisText += "<p>" + margen[i] + "% Marge: Netto: " + vkNettoMitRabatt.toFixed(2).replace('.', ',') +
                                                "€, Brutto: " + vkBruttoMitRabatt.toFixed(2).replace('.', ',') + "€ (" + tatsaechlicheMarge.toFixed(
                                                    2).replace('.', ',') + "% Marge nach Rabatt)" + ((angepassterRabatt > 0) ? " inkl. " +
                                                    angepassterRabatt.toFixed(2).replace('.', ',') + "% Rabatt" : "") + "</p>";
                                        }
                                    }

                                    document.getElementById('ergebnis').innerHTML = ergebnisText;
                                    return false; // verhindert das Neuladen der Seite
                                }
                            </script>
                        </head>

                        <body>
                            <h3>Marge- und Rabattberechnung</h3>
                            <form onsubmit="return berechneVerkaufspreise();">
                                <label for="ek">Einkaufspreis (Netto):</label>
                                <input type="number" id="ek" name="ek" step="0.01" required><br><br>

                                <label for="rabatt">Rabatt in % (max. 5%):</label>
                                <input type="number" id="rabatt" name="rabatt" step="0.01" min="0"
                                    max="5" onchange="berechneVerkaufspreise();"><br><br>

                                <input type="submit" value="Verkaufspreise berechnen">
                            </form>

                            <div id="hinweis"></div>
                            <div id="ergebnis"></div>
                        </body>

                        </html>
                        <! ENDE Marge- und Rabattberechnung>





                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>

    <script>
        document.getElementById('hinfahrtsdatum').addEventListener('change', function() {
            var hinfahrtsdatum = this.value;
            var rueckfahrtdatumElement = document.getElementById('rueckfahrtdatum');

            if (rueckfahrtdatumElement.value === '' || new Date(rueckfahrtdatumElement.value) < new Date(
                    hinfahrtsdatum)) {
                rueckfahrtdatumElement.value = hinfahrtsdatum;
            }
        });
    </script>
</body>

</html>
